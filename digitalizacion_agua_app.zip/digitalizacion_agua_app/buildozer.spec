[app]
title = Digitalizacion del Agua
package.name = digitalizacionagua
package.domain = org.bohoral

source.dir = .
source.include_exts = py,png,jpg,kv,atlas,ttf
version = 1.0.0

requirements = python3,kivy==2.3.0,plyer,pyshp,reportlab,pillow

orientation = portrait
fullscreen = 0

icon.filename = %(source.dir)s/assets/escudo.png

android.permissions = CAMERA,ACCESS_FINE_LOCATION,ACCESS_COARSE_LOCATION,WRITE_EXTERNAL_STORAGE,READ_EXTERNAL_STORAGE,INTERNET

android.api = 34
android.minapi = 24
android.ndk = 25b
android.archs = arm64-v8a,armeabi-v7a
android.accept_sdk_license = True

# Necesario para que plyer.camera pueda guardar el archivo vía FileProvider
android.add_src = 

[buildozer]
log_level = 2
warn_on_root = 1
